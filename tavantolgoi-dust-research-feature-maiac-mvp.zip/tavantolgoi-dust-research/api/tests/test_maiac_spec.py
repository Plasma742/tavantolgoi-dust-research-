"""QA bit logic and scaling, checked against the documented AOD_QA table (no Earth Engine)."""

from __future__ import annotations

import re
from pathlib import Path

import pytest

from app.datasets import maiac_spec as spec

ROOT = Path(__file__).resolve().parents[2]


def qa(cloud: int = 1, lwsi: int = 0, adjacency: int = 0, aodq: int = 0, glint: int = 0, model: int = 0) -> int:
    return cloud | (lwsi << 3) | (adjacency << 5) | (aodq << 8) | (glint << 12) | (model << 13)


def test_decode_round_trip() -> None:
    value = qa(cloud=3, lwsi=2, adjacency=5, aodq=11, glint=1, model=2)
    assert spec.decode_aod_qa(value) == {
        "cloud_mask": 3,
        "land_water_snow_ice": 2,
        "adjacency": 5,
        "aod_quality": 11,
        "glint": True,
        "aerosol_model": 2,
        "reserved": 0,
    }


def test_decode_rejects_out_of_range() -> None:
    with pytest.raises(ValueError):
        spec.decode_aod_qa(70000)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        (qa(), True),  # clear, land, best quality
        (qa(cloud=0), False),  # undefined cloud mask
        (qa(cloud=2), False),  # possibly cloudy
        (qa(cloud=3), False),  # cloudy
        (qa(cloud=5), False),  # cloud shadow
        (qa(lwsi=1), False),  # water
        (qa(lwsi=2), False),  # snow
        (qa(lwsi=3), False),  # ice
        (qa(aodq=3), False),  # one neighbouring cloud
        (qa(aodq=7), False),  # climatology AOD
        (qa(aodq=11), False),  # research quality only
        (qa(adjacency=1), True),  # adjacency NOT used by the strict rule (documented)
        (qa(glint=1), True),  # glint NOT used
        (qa(model=2), True),  # dust aerosol model NOT used as a filter
    ],
)
def test_strict_qa(value: int, expected: bool) -> None:
    assert spec.passes_strict_qa(value) is expected


def test_scaling_and_physical_range() -> None:
    assert spec.scale_raw_aod(123) == pytest.approx(0.123)
    assert spec.is_valid_retrieval(0, qa())  # AOD 0.000 included
    assert spec.is_valid_retrieval(8000, qa())  # AOD 8.000 included
    assert not spec.is_valid_retrieval(-50, qa())  # -0.05 excluded (follows smoke test; flagged for review)
    assert not spec.is_valid_retrieval(8001, qa())
    assert not spec.is_valid_retrieval(None, qa())
    assert not spec.is_valid_retrieval(100, None)
    assert not spec.is_valid_retrieval(100, qa(cloud=3))


def test_spec_matches_smoke_test_and_parity_script() -> None:
    """The backend rule must equal the Code Editor smoke test and the parity script."""
    smoke = (ROOT / "gee" / "maiac_smoke_test.js").read_text()
    parity = (ROOT / "gee" / "maiac_parity_check.js").read_text()
    assert "bitwiseAnd(7).eq(1)" in smoke
    assert "rightShift(3).bitwiseAnd(3).eq(0)" in smoke
    assert "rightShift(8).bitwiseAnd(15).eq(0)" in smoke
    assert "aod.gte(0).and(aod.lte(8))" in smoke
    assert "multiply(0.001)" in smoke
    cloud, land, aodq = spec.STRICT_QA_RULES
    assert (cloud.start_bit, cloud.mask, cloud.accepted) == (0, 7, (1,))
    assert (land.start_bit, land.mask, land.accepted) == (3, 3, (0,))
    assert (aodq.start_bit, aodq.mask, aodq.accepted) == (8, 15, (0,))
    assert (spec.PHYSICAL_MIN, spec.PHYSICAL_MAX, spec.SCALE_FACTOR) == (0.0, 8.0, 0.001)
    for token in (
        "rightShift(0).bitwiseAnd(7).eq(1)",
        "rightShift(3).bitwiseAnd(3).eq(0)",
        "rightShift(8).bitwiseAnd(15).eq(0)",
        "multiply(0.001)",
        "aod.gte(0).and(aod.lte(8))",
        "ee.Reducer.mean().unweighted()",
        "ee.Reducer.sum().unweighted()",
        spec.COLLECTION_ID,
    ):
        assert token in parity, token


def test_ee_module_has_no_hardcoded_constants() -> None:
    source = (ROOT / "api" / "app" / "datasets" / "maiac_ee.py").read_text()
    assert not re.search(r"0\.001|Optical_Depth_055|AOD_QA|MCD19A2", source), (
        "maiac_ee.py must take constants from maiac_spec"
    )


def test_palettes_are_hex() -> None:
    for vis in (spec.AOD_VIS, spec.COUNT_VIS, spec.NO_VALID_VIS):
        assert all(re.fullmatch(r"[0-9a-f]{6}", c) for c in vis["palette"])
