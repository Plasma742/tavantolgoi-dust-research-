"""Opt-in live Earth Engine test. Skipped unless explicitly enabled.

Run (from api/, after `earthengine authenticate` or ADC login):

    RUN_EE_INTEGRATION=1 EE_PROJECT_ID=<your-project> \
    TEST_ROI_GEOJSON=../data/roi/<your-verified-or-demo-roi>.geojson \
    python -m pytest tests/test_ee_integration.py -s

It checks internal consistency of real results; it does not prove scientific validity.
Compare the printed numbers with gee/maiac_parity_check.js in the Code Editor.
"""

from __future__ import annotations

import json
import os
from datetime import date
from pathlib import Path

import pytest

pytestmark = pytest.mark.skipif(
    os.environ.get("RUN_EE_INTEGRATION") != "1"
    or not os.environ.get("EE_PROJECT_ID")
    or not os.environ.get("TEST_ROI_GEOJSON"),
    reason="live Earth Engine test disabled (set RUN_EE_INTEGRATION=1, EE_PROJECT_ID, TEST_ROI_GEOJSON)",
)


def _geometry() -> dict:
    data = json.loads(Path(os.environ["TEST_ROI_GEOJSON"]).read_text())
    return data["geometry"] if data.get("type") == "Feature" else data


def test_april_2025_live() -> None:
    from app.config import load_settings
    from app.datasets.maiac_ee import MaiacEarthEngine
    from app.datasets.maiac_service import summarize
    from app.ee_runtime import EERuntime
    from app.periods import month_period

    EERuntime(load_settings()).ensure_ready()
    engine = MaiacEarthEngine()
    period = month_period("2025-04")
    raw = engine.period_stats(_geometry(), period.start, period.end_exclusive)
    summary = summarize(raw, period)
    print(json.dumps({"native_grid": engine.native_grid(), "raw": raw, "summary": summary}, indent=2))

    assert raw["granules_intersecting"] >= raw["granules_with_valid"] >= 0
    assert 0 <= raw["pixels_with_valid"] <= raw["pixels_total"]
    assert 0 <= raw["valid_retrievals"] <= raw["retrievals_before_qa"]
    assert raw["valid_day_count"] <= period.days
    assert summary["consistency_check_passed"], "pixel-sum and granule-sum valid counts disagree"
    if raw["roi_mean_aod"] is not None:
        assert 0.0 <= raw["roi_mean_aod"] <= 8.0
    fetchers = engine.layer_fetchers(_geometry(), date(2025, 4, 1), date(2025, 5, 1))
    assert set(fetchers) == {"aod_mean", "valid_count", "no_valid_retrieval"}
