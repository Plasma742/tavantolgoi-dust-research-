"""Shared fixtures. The fake engine returns TEST FIXTURE numbers only — never observations."""

from __future__ import annotations

from dataclasses import replace
from datetime import date
from pathlib import Path
from typing import Any

import pytest
from fastapi.testclient import TestClient

from app.config import Settings, load_settings
from app.main import create_app

# A small rectangle in the Gobi, used only as a test geometry. It is NOT a mine boundary.
TEST_RECT = {
    "type": "Polygon",
    "coordinates": [[[105.30, 43.50], [105.70, 43.50], [105.70, 43.80], [105.30, 43.80], [105.30, 43.50]]],
}


def make_settings(tmp_path: Path, **overrides: Any) -> Settings:
    base = replace(load_settings(), ee_project_id=None, roi_dir=tmp_path / "roi", code_revision="test-rev")
    return replace(base, **overrides)


class FakeRuntime:
    """Pretends Earth Engine initialised. Only used with FakeEngine."""

    earthengine_api_version = "fake"

    def ensure_ready(self) -> None:
        return None

    def snapshot(self) -> dict[str, Any]:
        return {
            "status": "READY",
            "message": None,
            "project_configured": True,
            "auth_mode": "fake",
            "earthengine_api_version": "fake",
        }


class FakeFetcher:
    def __init__(self, name: str):
        self.name = name
        self.calls: list[tuple[int, int, int]] = []

    def fetch_tile(self, x: float, y: float, z: float) -> bytes:
        self.calls.append((int(z), int(x), int(y)))
        return b"\x89PNG-fixture-" + self.name.encode()


class FakeEngine:
    """Deterministic TEST FIXTURE values keyed by period start month.

    * 2025-02 -> NO_GRANULES
    * 2025-03 -> granules but zero valid retrievals
    * otherwise -> plausible-looking fixture counts (not real data)
    """

    def __init__(self) -> None:
        self.stats_calls: list[tuple[date, date]] = []
        self.fetchers: dict[str, FakeFetcher] = {}

    def native_grid(self) -> dict[str, Any]:
        return {"crs": "SR-ORG:6974", "nominal_scale_m": 926.6254330555, "crs_transform": None, "wkt_available": False}

    def period_stats(self, geometry: dict[str, Any], start: date, end_exclusive: date) -> dict[str, Any]:
        self.stats_calls.append((start, end_exclusive))
        if (start.year, start.month) == (2025, 2):
            return {
                "granules_intersecting": 0,
                "granules_with_valid": 0,
                "valid_day_count": 0,
                "valid_retrievals_granule_sum": 0,
                "valid_retrievals": 0,
                "retrievals_before_qa": 0,
                "pixels_with_valid": 0,
                "pixels_total": 1200,
                "roi_mean_aod": None,
            }
        if (start.year, start.month) == (2025, 3):
            return {
                "granules_intersecting": 40,
                "granules_with_valid": 0,
                "valid_day_count": 0,
                "valid_retrievals_granule_sum": 0,
                "valid_retrievals": 0,
                "retrievals_before_qa": 9000,
                "pixels_with_valid": 0,
                "pixels_total": 1200,
                "roi_mean_aod": None,
            }
        return {
            "granules_intersecting": 60,
            "granules_with_valid": 30,
            "valid_day_count": 18,
            "valid_retrievals_granule_sum": 9000,
            "valid_retrievals": 9000,
            "retrievals_before_qa": 20000,
            "pixels_with_valid": 1100,
            "pixels_total": 1200,
            "roi_mean_aod": 0.123456,
        }

    def layer_fetchers(self, geometry: dict[str, Any], start: date, end_exclusive: date) -> dict[str, FakeFetcher]:
        self.fetchers = {k: FakeFetcher(k) for k in ("aod_mean", "valid_count", "no_valid_retrieval")}
        return self.fetchers  # type: ignore[return-value]


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    return make_settings(tmp_path)


@pytest.fixture
def unconfigured_client(settings: Settings) -> TestClient:
    return TestClient(create_app(settings))


@pytest.fixture
def engine() -> FakeEngine:
    return FakeEngine()


@pytest.fixture
def fake_client(settings: Settings, engine: FakeEngine) -> TestClient:
    app = create_app(settings, runtime=FakeRuntime(), engine_factory=lambda: engine)  # type: ignore[arg-type]
    return TestClient(app)


def roi_payload(**overrides: Any) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "geometry": TEST_RECT,
        "label": "Test rectangle (not a mine boundary)",
        "declared_status": "demonstration",
    }
    payload.update(overrides)
    return payload
