"""Tavan Tolgoi Dust Research Platform — FastAPI backend."""

__version__ = "0.1.0"
