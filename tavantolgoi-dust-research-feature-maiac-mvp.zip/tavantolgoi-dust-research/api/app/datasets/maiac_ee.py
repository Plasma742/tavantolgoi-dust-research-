"""Earth Engine implementation of the MAIAC AOD 550 nm processing.

Every constant comes from ``maiac_spec``. ``gee/maiac_parity_check.js`` mirrors this
module line-for-line so results can be cross-checked in the Code Editor.

This module needs an initialised Earth Engine session; it is never imported by
unit tests (they use a fake engine). See ``api/tests/test_ee_integration.py`` for
the opt-in live test.
"""

from __future__ import annotations

import threading
from datetime import date
from typing import Any

import ee

from . import maiac_spec as spec

# Server-side property names written onto granules during the per-granule pass.
_P_VALID = "tt_valid_px"
_P_DAY = "tt_utc_day"


def roi_geometry(geojson_geometry: dict[str, Any]) -> ee.Geometry:
    # Planar (non-geodesic) edges in EPSG:4326, as RFC 7946 GeoJSON and Code Editor
    # drawn geometries are interpreted.
    return ee.Geometry(geojson_geometry, "EPSG:4326", False)


def qa_filter(image: ee.Image) -> ee.Image:
    """Scale the AOD band and mask everything that fails the strict QA rule."""
    qa = image.select(spec.QA_BAND)
    keep = ee.Image.constant(1)
    for rule in spec.STRICT_QA_RULES:
        field = qa.rightShift(rule.start_bit).bitwiseAnd(rule.mask)
        accepted = field.eq(rule.accepted[0])
        for value in rule.accepted[1:]:
            accepted = accepted.Or(field.eq(value))
        keep = keep.And(accepted)
    aod = image.select(spec.AOD_BAND).multiply(spec.SCALE_FACTOR).add(spec.OFFSET)
    physical = aod.gte(spec.PHYSICAL_MIN).And(aod.lte(spec.PHYSICAL_MAX))
    return ee.Image(
        aod.updateMask(keep.And(physical)).rename(spec.DERIVED_BAND).copyProperties(image, ["system:time_start"])
    )


def _raw_present(image: ee.Image) -> ee.Image:
    """Raw AOD values present before QA (unmasked and inside the documented raw range)."""
    raw = image.select(spec.AOD_BAND)
    present = raw.gte(spec.RAW_VALID_MIN).And(raw.lte(spec.RAW_VALID_MAX))
    return raw.updateMask(present).rename("raw")


def _fully_masked(band: str) -> ee.Image:
    return ee.Image.constant(0).toFloat().rename(band).selfMask()


class _Composites:
    """Server-side images for one ROI and period (no network calls are made here)."""

    def __init__(self, geometry: dict[str, Any], start: date, end_exclusive: date):
        self.roi = roi_geometry(geometry)
        self.raw = (
            ee.ImageCollection(spec.COLLECTION_ID)
            .filterBounds(self.roi)
            .filterDate(start.isoformat(), end_exclusive.isoformat())
        )
        self.n_raw = self.raw.size()
        has_any = self.n_raw.gt(0)
        filtered = self.raw.map(qa_filter)
        present = self.raw.map(_raw_present)
        # Guard against empty collections: mean()/count() of an empty collection has no bands.
        self.filtered = ee.ImageCollection(
            ee.Algorithms.If(has_any, filtered, ee.ImageCollection([_fully_masked(spec.DERIVED_BAND)]))
        )
        present_safe = ee.ImageCollection(
            ee.Algorithms.If(has_any, present, ee.ImageCollection([_fully_masked("raw")]))
        )
        self.mean = self.filtered.select(spec.DERIVED_BAND).mean().rename("aod_mean")
        self.valid_count = self.filtered.select(spec.DERIVED_BAND).count().unmask(0).rename("valid_obs")
        self.raw_count = present_safe.select("raw").count().unmask(0).rename("raw_obs")


class MaiacEarthEngine:
    """Real engine. Methods block on Earth Engine and may raise ``ee.EEException``."""

    def __init__(self, max_pixels: int = 10_000_000):
        self._max_pixels = max_pixels
        self._grid_lock = threading.Lock()
        self._grid: dict[str, Any] | None = None

    # -- native grid ---------------------------------------------------------------
    def _projection(self) -> ee.Projection:
        return ee.ImageCollection(spec.COLLECTION_ID).first().select(spec.AOD_BAND).projection()

    def native_grid(self) -> dict[str, Any]:
        with self._grid_lock:
            if self._grid is None:
                proj = self._projection()
                info = ee.Dictionary({"projection": proj, "nominal_scale_m": proj.nominalScale()}).getInfo()
                self._grid = {
                    "crs": info["projection"].get("crs"),
                    "wkt_available": "wkt" in info["projection"],
                    "crs_transform": info["projection"].get("transform"),
                    "nominal_scale_m": info["nominal_scale_m"],
                }
            return self._grid

    # -- statistics ----------------------------------------------------------------
    def period_stats(self, geometry: dict[str, Any], start: date, end_exclusive: date) -> dict[str, Any]:
        c = _Composites(geometry, start, end_exclusive)
        proj = self._projection()
        common = {"geometry": c.roi, "crs": proj, "maxPixels": self._max_pixels, "bestEffort": False}

        has_valid = c.valid_count.gt(0).rename("has_valid")
        roi_px = ee.Image.constant(1).rename("roi_px")
        sums = ee.Image.cat([c.valid_count, c.raw_count, has_valid, roi_px]).reduceRegion(
            reducer=ee.Reducer.sum().unweighted(), **common
        )
        mean = c.mean.reduceRegion(reducer=ee.Reducer.mean().unweighted(), **common)

        def per_granule(img: ee.Image) -> ee.Image:
            n = qa_filter(img).reduceRegion(reducer=ee.Reducer.count(), **common).get(spec.DERIVED_BAND)
            day = ee.Date(img.get("system:time_start")).format("YYYY-MM-dd")
            return img.set({_P_VALID: n, _P_DAY: day})

        granules = c.raw.map(per_granule)
        with_valid = granules.filter(ee.Filter.gt(_P_VALID, 0))

        out = ee.Dictionary(
            {
                "granules_intersecting": c.n_raw,
                "granules_with_valid": with_valid.size(),
                "valid_day_count": with_valid.aggregate_array(_P_DAY).distinct().size(),
                "valid_retrievals_granule_sum": granules.aggregate_sum(_P_VALID),
                "sums": sums,
                "mean": mean,
            }
        ).getInfo()

        sums_info = out["sums"] or {}
        return {
            "granules_intersecting": int(out["granules_intersecting"]),
            "granules_with_valid": int(out["granules_with_valid"]),
            "valid_day_count": int(out["valid_day_count"]),
            "valid_retrievals_granule_sum": round(float(out["valid_retrievals_granule_sum"] or 0)),
            "valid_retrievals": round(float(sums_info.get("valid_obs") or 0)),
            "retrievals_before_qa": round(float(sums_info.get("raw_obs") or 0)),
            "pixels_with_valid": round(float(sums_info.get("has_valid") or 0)),
            "pixels_total": round(float(sums_info.get("roi_px") or 0)),
            "roi_mean_aod": (out["mean"] or {}).get("aod_mean"),
        }

    # -- map tiles -----------------------------------------------------------------
    def layer_fetchers(self, geometry: dict[str, Any], start: date, end_exclusive: date) -> dict[str, Any]:
        c = _Composites(geometry, start, end_exclusive)
        aod = c.mean.clip(c.roi)
        count = c.valid_count.updateMask(c.valid_count.gt(0)).clip(c.roi)
        none_valid = c.valid_count.eq(0).selfMask().clip(c.roi)
        layers = {
            "aod_mean": aod.getMapId({**spec.AOD_VIS, "format": "png"}),
            "valid_count": count.getMapId({**spec.COUNT_VIS, "format": "png"}),
            "no_valid_retrieval": none_valid.getMapId({"min": 0, "max": 1, **spec.NO_VALID_VIS, "format": "png"}),
        }
        return {key: value["tile_fetcher"] for key, value in layers.items()}
