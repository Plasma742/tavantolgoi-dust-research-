"""MAIAC MCD19A2.061 processing specification — pure Python, no Earth Engine import.

This module is the single source of truth for the MAIAC constants used by:

* the Earth Engine implementation (``maiac_ee.py``),
* the API method documentation (``GET /api/methods``),
* provenance records attached to every response, and
* unit tests that check the QA bit logic without Earth Engine access.

Sources (checked 2026-11-04):

* GEE catalog, MODIS/061/MCD19A2_GRANULES: Optical_Depth_055 raw range -100..8000,
  scale 0.001; AOD_Uncertainty scale 0.0001; catalog pixel size 1000 m.
* MAIAC C6/C6.1 user guide and LAADS file spec, AOD_QA bit table:
  bits 0-2 cloud mask (001 = clear), bits 3-4 land/water/snow/ice (00 = land),
  bits 5-7 adjacency mask, bits 8-11 QA for AOD (0000 = best quality),
  bit 12 glint mask, bits 13-14 aerosol model, bit 15 reserved.

The strict QA rule and the physical-range screen below reproduce
``gee/maiac_smoke_test.js`` exactly. Any change to them is a methodology change:
bump ``METHOD_VERSION`` and record it in the research protocol.
"""

from __future__ import annotations

from dataclasses import dataclass

METHOD_VERSION = "maiac-aod550-strict-qa/0.1.0"

DATASET_KEY = "maiac_aod550"
COLLECTION_ID = "MODIS/061/MCD19A2_GRANULES"
DATASET_TITLE = "MCD19A2.061 Terra & Aqua MAIAC Land Aerosol Optical Depth Daily 1 km"
CATALOG_URL = "https://developers.google.com/earth-engine/datasets/catalog/MODIS_061_MCD19A2_GRANULES"
CITATION = (
    "MODIS/Terra+Aqua Land Aerosol Optical Depth Daily L2G Global 1km SIN Grid V061 "
    "(MCD19A2.061). NASA EOSDIS Land Processes DAAC. https://doi.org/10.5067/MODIS/MCD19A2.061 "
    "— see the LP DAAC 'Citing Our Data' page for the full citation format."
)
DATASET_START_DATE = "2000-02-24"  # GEE catalog availability start

AOD_BAND = "Optical_Depth_055"
QA_BAND = "AOD_QA"
DERIVED_BAND = "AOD_550"
SCALE_FACTOR = 0.001
OFFSET = 0.0
UNIT = "dimensionless"
QUANTITY = "Aerosol optical depth at 550 nm (column-integrated, atmosphere total)"

# Raw integer range documented in the GEE catalog for Optical_Depth_055.
# Used only to count "AOD values present before QA" so fill values are never counted.
RAW_VALID_MIN = -100
RAW_VALID_MAX = 8000

# Physical-range screen applied AFTER scaling, as in gee/maiac_smoke_test.js.
# NOTE for methodology review: the product's valid range includes small negative
# retrievals (down to -0.1). Excluding them (min 0) follows the smoke test but can bias
# clean-air means upward. Flagged for review; not changed unilaterally.
PHYSICAL_MIN = 0.0
PHYSICAL_MAX = 8.0

CATALOG_PIXEL_SIZE_M = 1000  # nominal value in the GEE catalog


@dataclass(frozen=True)
class BitRule:
    """Accept a pixel when ``(qa >> start_bit) & ((1 << n_bits) - 1)`` is in ``accepted``."""

    name: str
    start_bit: int
    n_bits: int
    accepted: tuple[int, ...]
    meaning: str

    @property
    def mask(self) -> int:
        return (1 << self.n_bits) - 1

    def field(self, qa: int) -> int:
        return (qa >> self.start_bit) & self.mask

    def passes(self, qa: int) -> bool:
        return self.field(qa) in self.accepted


STRICT_QA_RULES: tuple[BitRule, ...] = (
    BitRule("cloud_mask", 0, 3, (1,), "bits 0-2 == 1 (clear)"),
    BitRule("land_water_snow_ice", 3, 2, (0,), "bits 3-4 == 0 (land)"),
    BitRule("aod_quality", 8, 4, (0,), "bits 8-11 == 0 (best quality)"),
)

# Documented field meanings, used for decoding/inspection and tests.
CLOUD_MASK_VALUES = {
    0: "undefined",
    1: "clear",
    2: "possibly cloudy (detected by AOD filter)",
    3: "cloudy (detected by cloud mask algorithm)",
    5: "cloud shadow",
    6: "hot spot of fire",
    7: "water sediments",
}
LAND_WATER_SNOW_ICE_VALUES = {0: "land", 1: "water", 2: "snow", 3: "ice"}
ADJACENCY_VALUES = {
    0: "normal condition / clear",
    1: "adjacent to clouds",
    2: "surrounded by more than 8 cloudy pixels",
    3: "adjacent to a single cloudy pixel",
    4: "adjacent to snow",
    5: "snow was previously detected in this pixel",
}
AOD_QUALITY_VALUES = {
    0: "best quality",
    1: "water sediments are detected (water)",
    3: "there is 1 neighbouring cloud",
    4: "there is more than 1 neighbouring cloud",
    5: "no retrieval (cloudy, or other)",
    6: "no retrievals near detected or previously detected snow",
    7: "climatology AOD: altitude above 3.5 km (water) / 4.2 km (land)",
    8: "no retrieval due to sun glint (water)",
    9: "retrieved AOD is very low (<0.05) due to glint (water)",
    10: "AOD within +-2 km from the coastline (may be unreliable)",
    11: "land, research quality: AOD retrieved but cloud mask is possibly cloudy",
}
AEROSOL_MODEL_VALUES = {0: "background model (regional)", 1: "smoke model (regional)", 2: "dust model"}


def decode_aod_qa(qa: int) -> dict[str, int | bool]:
    """Decode a 16-bit AOD_QA value into its documented fields."""
    if not 0 <= qa <= 0xFFFF:
        raise ValueError("AOD_QA must be a 16-bit unsigned integer")
    return {
        "cloud_mask": qa & 0b111,
        "land_water_snow_ice": (qa >> 3) & 0b11,
        "adjacency": (qa >> 5) & 0b111,
        "aod_quality": (qa >> 8) & 0b1111,
        "glint": bool((qa >> 12) & 0b1),
        "aerosol_model": (qa >> 13) & 0b11,
        "reserved": (qa >> 15) & 0b1,
    }


def passes_strict_qa(qa: int) -> bool:
    return all(rule.passes(qa) for rule in STRICT_QA_RULES)


def scale_raw_aod(raw: int) -> float:
    return raw * SCALE_FACTOR + OFFSET


def passes_physical_range(aod: float) -> bool:
    return PHYSICAL_MIN <= aod <= PHYSICAL_MAX


def is_valid_retrieval(raw_aod: int | None, qa: int | None) -> bool:
    """Pure-Python mirror of the Earth Engine per-pixel mask (for tests and docs)."""
    if raw_aod is None or qa is None:
        return False
    return passes_strict_qa(qa) and passes_physical_range(scale_raw_aod(raw_aod))


QA_RULE_TEXT = (
    "AOD_QA bits 0-2 == 1 (clear) AND bits 3-4 == 0 (land) AND bits 8-11 == 0 (best quality); "
    f"then {PHYSICAL_MIN:g} <= AOD <= {PHYSICAL_MAX:g} after scaling by {SCALE_FACTOR:g}. "
    "Adjacency (bits 5-7), glint (bit 12) and aerosol-model (bits 13-14) fields are not used."
)

TEMPORAL_AGGREGATION_TEXT = (
    "Per-pixel arithmetic mean of all QA-passing granule retrievals with "
    "time_start in [start, end_exclusive) (UTC). Granules are treated as independent "
    "overpass retrievals; cloud/QA gaps are missing data, never zero."
)

SPATIAL_REDUCTION_TEXT = (
    "ROI statistics are computed on the MAIAC native sinusoidal grid (projection taken "
    "from the collection's own Optical_Depth_055 band). Earth Engine unweighted reducers "
    "include a pixel when its centre lies inside the ROI. ROI mean AOD = unweighted mean, "
    "over ROI pixels with at least one valid retrieval, of each pixel's period mean."
)

NOT_A_MEASUREMENT_OF = (
    "PM10",
    "PM2.5",
    "surface (ground-level) dust concentration",
    "dust emission rate",
    "dust attributable to the Tavan Tolgoi mine",
)

CAVEAT = (
    "Column AOD at 550 nm is an optical property of the whole atmospheric column. It is not "
    "ground-level PM10/PM2.5 and an AOD pattern is not, by itself, evidence of mine-generated "
    "dust. Cloud, snow and QA gaps are missing data."
)

# Visualisation (single source for EE tiles and the web legend).
# AOD: single-hue blue sequential ramp (dataviz reference palette steps 100..700).
AOD_VIS = {
    "min": 0.0,
    "max": 1.0,
    "palette": [
        "cde2fb",
        "b7d3f6",
        "9ec5f4",
        "86b6ef",
        "6da7ec",
        "5598e7",
        "3987e5",
        "2a78d6",
        "256abf",
        "1c5cab",
        "184f95",
        "104281",
        "0d366b",
    ],
}
# Valid-observation count: single-hue orange sequential ramp (OKLCH hue ~41 deg).
COUNT_VIS = {
    "min": 1,
    "max": 25,
    "palette": ["f3bca8", "ed997a", "e4744a", "d64c00", "b13e02", "8d2f00", "6f2401"],
}
NO_VALID_VIS = {"palette": ["8a8a86"]}
