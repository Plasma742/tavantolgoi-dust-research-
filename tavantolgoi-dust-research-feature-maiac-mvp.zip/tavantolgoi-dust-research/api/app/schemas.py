"""Request and response models (also published as OpenAPI at /api/openapi.json)."""

from __future__ import annotations

from datetime import date
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, model_validator

DeclaredStatus = Literal["demonstration", "unverified_upload", "user_declared_verified", "registry"]
PeriodStatus = Literal["OK", "NO_GRANULES", "NO_VALID_OBSERVATIONS"]


class RoiInput(BaseModel):
    model_config = ConfigDict(extra="forbid")

    geometry: dict[str, Any] | None = Field(
        None, description="GeoJSON Polygon or MultiPolygon in WGS84 lon/lat. Omit when registry_id is set."
    )
    registry_id: str | None = Field(None, max_length=120, description="ID of a server-registered ROI.")
    label: str = Field(..., min_length=1, max_length=120)
    declared_status: DeclaredStatus
    source_note: str | None = Field(None, max_length=500)

    @model_validator(mode="after")
    def _check(self) -> RoiInput:
        if self.declared_status == "registry":
            if not self.registry_id:
                raise ValueError("registry_id is required when declared_status is 'registry'.")
        elif self.geometry is None:
            raise ValueError("geometry is required unless a registry ROI is used.")
        if self.declared_status == "user_declared_verified" and not (self.source_note or "").strip():
            raise ValueError("A source_note is required to declare an uploaded ROI as verified.")
        return self


class MaiacLayerRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    roi: RoiInput
    start: date = Field(..., description="Inclusive UTC start date.")
    end_exclusive: date = Field(..., description="Exclusive UTC end date (Earth Engine filterDate semantics).")


class MonthlySeriesRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    roi: RoiInput
    start_month: str = Field(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$")
    end_month: str = Field(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])$", description="Inclusive.")


class PeriodSummary(BaseModel):
    status: PeriodStatus
    status_message: str
    time_start_utc: str
    time_end_exclusive_utc: str
    days_in_period: int
    roi_mean_aod: float | None = Field(
        description="Unweighted mean over ROI pixels with >=1 valid retrieval of each pixel's period mean. "
        "Dimensionless AOD at 550 nm. null when no valid retrieval exists."
    )
    pixels_total: int = Field(description="Native-grid pixels whose centre lies in the ROI.")
    pixels_with_valid: int
    coverage_fraction: float | None
    valid_retrievals: int = Field(description="Sum over ROI pixels of QA-passing granule retrievals.")
    retrievals_before_qa: int = Field(description="Sum over ROI pixels of AOD values present before QA.")
    qa_retention_fraction: float | None
    granules_intersecting: int
    granules_with_valid: int
    valid_day_count: int = Field(description="Distinct UTC days with >=1 valid retrieval anywhere in the ROI.")
    consistency_check_passed: bool = Field(
        description="valid_retrievals (pixel sum) equals the per-granule sum computed independently."
    )


class MonthlyRow(PeriodSummary):
    month: str


class LegendStop(BaseModel):
    value: float
    label: str


class LayerLegend(BaseModel):
    kind: Literal["continuous", "categorical"]
    title: str
    unit: str
    palette: list[str]
    min: float | None = None
    max: float | None = None
    ticks: list[LegendStop] = []
    note: str


class MapLayer(BaseModel):
    id: str
    title: str
    observation_type: str
    tile_url_template: str
    max_native_zoom: int
    default_visible: bool
    default_opacity: float
    legend: LayerLegend


class LayerResponse(BaseModel):
    status: PeriodStatus
    dataset_key: str
    layers: list[MapLayer]
    summary: PeriodSummary
    provenance: dict[str, Any]
    tiles_note: str


class MonthlySeriesResponse(BaseModel):
    dataset_key: str
    rows: list[MonthlyRow]
    provenance: dict[str, Any]
