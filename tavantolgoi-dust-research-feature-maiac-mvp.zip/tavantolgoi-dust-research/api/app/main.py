"""FastAPI application: Tavan Tolgoi Dust Research Platform API.

Run locally (from api/):  uvicorn app.main:app --host 127.0.0.1 --port 8000 --env-file .env
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse, Response

from . import __version__
from .config import Settings, load_settings
from .csv_export import monthly_csv
from .datasets import maiac_spec
from .datasets.maiac_service import MaiacEngine, MaiacService
from .datasets.registry import DATASETS, UNAVAILABLE_MODULES, get_dataset
from .ee_runtime import EERuntime
from .errors import ApiError, NotImplementedDataset, UnknownDataset, classify_ee_error
from .roi import load_registry
from .schemas import LayerResponse, MaiacLayerRequest, MonthlySeriesRequest, MonthlySeriesResponse
from .tiles import TileRegistry

log = logging.getLogger("tavantolgoi.api")


def _default_engine_factory(settings: Settings) -> Callable[[], MaiacEngine]:
    def factory() -> MaiacEngine:
        from .datasets.maiac_ee import MaiacEarthEngine  # imports `ee`; only after init succeeded

        return MaiacEarthEngine(max_pixels=settings.ee_max_pixels)

    return factory


def create_app(
    settings: Settings | None = None,
    *,
    runtime: EERuntime | None = None,
    engine_factory: Callable[[], MaiacEngine] | None = None,
) -> FastAPI:
    settings = settings or load_settings()
    runtime = runtime or EERuntime(settings)
    tiles = TileRegistry(ttl_s=settings.layer_cache_ttl_s + 300, max_zoom=settings.tile_max_zoom)
    registry, registry_problems = load_registry(
        settings.roi_dir,
        max_area_km2=settings.max_roi_area_km2,
        max_vertices=settings.max_roi_vertices,
        allowed_bbox=settings.allowed_bbox,
    )
    maiac = MaiacService(settings, runtime, engine_factory or _default_engine_factory(settings), tiles, registry)

    app = FastAPI(
        title="Tavan Tolgoi Dust Research Platform API",
        version=__version__,
        description="Research prototype. Serves QA-filtered MAIAC AOD (550 nm) from Google Earth Engine. "
        "AOD is column aerosol optical depth, not PM10 and not mine-attributed dust.",
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
        redoc_url=None,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=list(settings.allowed_origins),
        allow_methods=["GET", "POST"],
        allow_headers=["Content-Type"],
        allow_credentials=False,
    )

    @app.middleware("http")
    async def limit_body_size(request: Request, call_next: Any) -> Response:
        length = request.headers.get("content-length")
        if length and length.isdigit() and int(length) > settings.max_request_bytes:
            return JSONResponse(
                status_code=413,
                content=ApiError(
                    f"Request body larger than {settings.max_request_bytes} bytes.", code="PAYLOAD_TOO_LARGE"
                ).body(),
            )
        return await call_next(request)

    @app.exception_handler(ApiError)
    async def api_error_handler(_: Request, exc: ApiError) -> JSONResponse:
        return JSONResponse(status_code=exc.status_code, content=exc.body())

    @app.exception_handler(RequestValidationError)
    async def validation_handler(_: Request, exc: RequestValidationError) -> JSONResponse:
        details = [{"loc": list(e.get("loc", [])), "msg": e.get("msg")} for e in exc.errors()]
        return JSONResponse(
            status_code=422,
            content=ApiError("Request failed validation.", code="VALIDATION_ERROR", details=details).body(),
        )

    # -- meta ------------------------------------------------------------------------
    @app.get("/api/health")
    def health(check_earth_engine: bool = False) -> dict[str, Any]:
        """Service status. ``check_earth_engine=true`` attempts Earth Engine initialisation."""
        if check_earth_engine and settings.ee_configured:
            try:
                runtime.ensure_ready()
            except ApiError:
                pass  # reported in the snapshot below
        return {
            "status": "ok",
            "version": __version__,
            "code_revision": settings.code_revision,
            "earth_engine": runtime.snapshot(),
            "limits": {
                "max_roi_area_km2": settings.max_roi_area_km2,
                "max_roi_vertices": settings.max_roi_vertices,
                "allowed_bbox": list(settings.allowed_bbox),
                "max_layer_days": settings.max_layer_days,
                "max_series_months": settings.max_series_months,
            },
            "deployment": "local research prototype — not publicly deployed",
        }

    @app.get("/api/datasets")
    def datasets() -> dict[str, Any]:
        return {"datasets": list(DATASETS.values()), "unavailable_modules": UNAVAILABLE_MODULES}

    @app.get("/api/methods")
    def methods() -> dict[str, Any]:
        return {
            "method_version": maiac_spec.METHOD_VERSION,
            "code_revision": settings.code_revision,
            "maiac": {
                "dataset_id": maiac_spec.COLLECTION_ID,
                "band": maiac_spec.AOD_BAND,
                "qa_band": maiac_spec.QA_BAND,
                "scale_factor": maiac_spec.SCALE_FACTOR,
                "unit": maiac_spec.UNIT,
                "quality_filter": maiac_spec.QA_RULE_TEXT,
                "physical_range": [maiac_spec.PHYSICAL_MIN, maiac_spec.PHYSICAL_MAX],
                "temporal_aggregation": maiac_spec.TEMPORAL_AGGREGATION_TEXT,
                "spatial_reduction": maiac_spec.SPATIAL_REDUCTION_TEXT,
                "not_a_measurement_of": list(maiac_spec.NOT_A_MEASUREMENT_OF),
                "caveat": maiac_spec.CAVEAT,
                "citation": maiac_spec.CITATION,
                "catalog_url": maiac_spec.CATALOG_URL,
                "open_methodology_questions": [
                    "Physical-range screen excludes valid small negative AOD (product range starts at -0.1); "
                    "this follows the smoke test but may bias clean-air means upward.",
                    "The strict QA rule does not use the adjacency mask (bits 5-7).",
                    "gee/maiac_smoke_test.js reduces the composite at scale 1000 m in its default "
                    "projection (EPSG:4326) with a fractional-pixel-weighted mean; the backend uses the "
                    "native sinusoidal grid with unweighted reducers. gee/maiac_parity_check.js mirrors the backend.",
                ],
            },
            "quota_note": "Earth Engine noncommercial projects have monthly EECU-hour quotas (since 27 April 2026). "
            "The backend bounds ROI size, period length and series length, and caches results.",
        }

    @app.get("/api/rois")
    def rois() -> dict[str, Any]:
        return {
            "rois": [entry.public() for entry in registry.values()],
            "problems": registry_problems,
            "note": "Only server-registered ROIs are listed. Drawn or uploaded ROIs are labelled by their "
            "declared status.",
        }

    # -- data ------------------------------------------------------------------------
    def _require_implemented(dataset_key: str) -> None:
        meta = get_dataset(dataset_key)
        if meta is None:
            raise UnknownDataset(f"Unknown dataset '{dataset_key}'.")
        if meta["status"] != "implemented":
            raise NotImplementedDataset(
                f"'{dataset_key}' is planned but not implemented yet.", details={"dataset": meta["collection_id"]}
            )

    @app.post("/api/layers/{dataset_key}", response_model=LayerResponse)
    def layer(dataset_key: str, body: MaiacLayerRequest) -> dict[str, Any]:
        _require_implemented(dataset_key)
        return maiac.layer(body)

    @app.post("/api/stats/{dataset_key}/monthly", response_model=MonthlySeriesResponse)
    def monthly(dataset_key: str, body: MonthlySeriesRequest) -> dict[str, Any]:
        _require_implemented(dataset_key)
        return maiac.monthly(body)

    @app.post("/api/stats/{dataset_key}/monthly.csv", response_class=PlainTextResponse)
    def monthly_csv_export(dataset_key: str, body: MonthlySeriesRequest) -> PlainTextResponse:
        _require_implemented(dataset_key)
        text = monthly_csv(maiac.monthly(body))
        filename = f"maiac_aod550_monthly_{body.start_month}_{body.end_month}.csv"
        return PlainTextResponse(
            text, media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )

    @app.get("/api/tiles/{tile_id}/{z}/{x}/{y}.png")
    def tile(tile_id: str, z: int, x: int, y: int) -> Response:
        try:
            png, _ = tiles.get_tile(tile_id, z, x, y)
        except ApiError:
            raise
        except Exception as exc:
            raise classify_ee_error(exc) from exc
        return Response(content=png, media_type="image/png", headers={"Cache-Control": "private, max-age=3600"})

    app.state.settings = settings
    app.state.runtime = runtime
    app.state.registry_dir = str(Path(settings.roi_dir))
    return app


app = create_app()
