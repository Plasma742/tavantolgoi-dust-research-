"""CSV export of a monthly MAIAC series with a provenance header.

Rounding: ROI mean AOD is written to 0.001, the product's quantisation step. This is a
display/export precision, not an uncertainty estimate. Fractions are written to 0.0001.
"""

from __future__ import annotations

import csv
import io
from typing import Any

COLUMNS = (
    "month",
    "status",
    "time_start_utc",
    "time_end_exclusive_utc",
    "days_in_period",
    "roi_mean_aod_550",
    "pixels_total",
    "pixels_with_valid",
    "coverage_fraction",
    "valid_retrievals",
    "retrievals_before_qa",
    "qa_retention_fraction",
    "granules_intersecting",
    "granules_with_valid",
    "valid_day_count",
    "consistency_check_passed",
)


def _safe(text: Any) -> str:
    """Neutralise spreadsheet formula injection in free-text fields."""
    value = "" if text is None else str(text).replace("\n", " ").replace("\r", " ")
    return "'" + value if value[:1] in ("=", "+", "-", "@", "\t") else value


def _fmt(value: float | None, digits: int) -> str:
    return "" if value is None else f"{value:.{digits}f}"


def monthly_csv(series: dict[str, Any]) -> str:
    prov = series["provenance"]
    roi = prov["roi"]
    proc = prov["processing"]
    header = [
        ("title", "MAIAC AOD 550 nm monthly ROI summary (QA-filtered)"),
        ("observation_type", prov["observation_type"]),
        ("dataset_id", prov["dataset_id"]),
        ("band", f"{prov['band']} -> {prov['derived_band']}"),
        ("unit", prov["unit"]),
        ("scale_factor", prov["scale_factor"]),
        ("quality_filter", prov["quality_filter"]["text"]),
        ("temporal_aggregation", prov["temporal_aggregation"]),
        ("spatial_reduction", prov["spatial_reduction"]),
        ("roi_label", _safe(roi.get("label"))),
        ("roi_declared_status", roi.get("declared_status")),
        ("roi_status_description", roi.get("status_description")),
        ("roi_source_note", _safe(roi.get("source_note"))),
        ("roi_sha256", roi.get("sha256")),
        ("method_version", proc["method_version"]),
        ("code_revision", proc.get("code_revision")),
        ("earthengine_api_version", proc.get("earthengine_api_version")),
        ("computed_at_utc", proc["computed_at_utc"]),
        ("source_url", prov["source_url"]),
        ("citation", prov["citation"]),
        (
            "rounding",
            "roi_mean_aod_550 rounded to 0.001 (product quantisation), fractions to 0.0001; not uncertainty estimates",
        ),
        ("missing_values", "empty roi_mean_aod_550 = no valid retrieval (see status); never zero"),
        ("not_a_measurement_of", "; ".join(prov["not_a_measurement_of"])),
        ("caveat", prov["caveat"]),
    ]
    buf = io.StringIO()
    for key, value in header:
        buf.write(f"# {key}: {'' if value is None else value}\n")
    writer = csv.writer(buf, lineterminator="\n")
    writer.writerow(COLUMNS)
    for row in series["rows"]:
        writer.writerow(
            [
                row["month"],
                row["status"],
                row["time_start_utc"],
                row["time_end_exclusive_utc"],
                row["days_in_period"],
                _fmt(row["roi_mean_aod"], 3),
                row["pixels_total"],
                row["pixels_with_valid"],
                _fmt(row["coverage_fraction"], 4),
                row["valid_retrievals"],
                row["retrievals_before_qa"],
                _fmt(row["qa_retention_fraction"], 4),
                row["granules_intersecting"],
                row["granules_with_valid"],
                row["valid_day_count"],
                str(row["consistency_check_passed"]).lower(),
            ]
        )
    return buf.getvalue()
