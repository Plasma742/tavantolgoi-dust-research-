/**
 * MAIAC MCD19A2.061 AOD 550 nm — PARITY CHECK for the FastAPI backend.
 *
 * Mirrors api/app/datasets/maiac_ee.py line for line (method maiac-aod550-strict-qa/0.1.0):
 *   - strict QA: cloud bits 0-2 == 1, land bits 3-4 == 0, AOD quality bits 8-11 == 0
 *   - scale 0.001, physical screen 0 <= AOD <= 8
 *   - statistics on the MAIAC native sinusoidal grid, UNWEIGHTED reducers
 *     (a pixel counts when its centre lies inside the ROI)
 *
 * How to use:
 *   1. Paste into https://code.earthengine.google.com/
 *   2. Import the SAME GeoJSON polygon you send to the backend as `roiGeoJson` below
 *      (copy it from the dashboard's provenance drawer or your ROI file).
 *   3. Run, then compare the printed dictionary with the dashboard's "Period summary"
 *      and the API response `summary` (same month, same ROI sha256).
 *
 * Differences from gee/maiac_smoke_test.js (kept unchanged as the original baseline):
 *   the smoke test reduces at `scale: 1000` in the composite's default projection
 *   (EPSG:4326) with EE's default fractional-pixel weighting, so its ROI mean can differ
 *   slightly from this script and from the backend.
 *
 * This is NOT a dust-emission map and attributes nothing to mining.
 */

// ---- inputs -----------------------------------------------------------------------
var roiGeoJson = {
  // Replace with your ROI (WGS84 lon/lat). Example placeholder ring is NOT a mine boundary.
  type: 'Polygon',
  coordinates: [[[105.30, 43.50], [105.70, 43.50], [105.70, 43.80], [105.30, 43.80], [105.30, 43.50]]]
};
var start = '2025-04-01';
var endExclusive = '2025-05-01';

// ---- processing (mirror of maiac_ee.py) -------------------------------------------
var COLLECTION_ID = 'MODIS/061/MCD19A2_GRANULES';
var roi = ee.Geometry(roiGeoJson, 'EPSG:4326', false);  // planar edges, as the backend

function qaFilter(image) {
  var qa = image.select('AOD_QA');
  var keep = ee.Image.constant(1)
    .and(qa.rightShift(0).bitwiseAnd(7).eq(1))    // cloud mask: clear
    .and(qa.rightShift(3).bitwiseAnd(3).eq(0))    // land
    .and(qa.rightShift(8).bitwiseAnd(15).eq(0));  // best AOD quality
  var aod = image.select('Optical_Depth_055').multiply(0.001).add(0);
  var physical = aod.gte(0).and(aod.lte(8));
  return ee.Image(aod.updateMask(keep.and(physical)).rename('AOD_550')
    .copyProperties(image, ['system:time_start']));
}

function rawPresent(image) {
  var raw = image.select('Optical_Depth_055');
  return raw.updateMask(raw.gte(-100).and(raw.lte(8000))).rename('raw');
}

// If no granule intersects the ROI in the period, mean()/count() below fail: that is the
// backend's NO_GRANULES case.
var raw = ee.ImageCollection(COLLECTION_ID).filterBounds(roi).filterDate(start, endExclusive);
var filtered = raw.map(qaFilter);
var proj = ee.ImageCollection(COLLECTION_ID).first().select('Optical_Depth_055').projection();

var meanAod = filtered.mean().rename('aod_mean');
var validCount = filtered.count().unmask(0).rename('valid_obs');
var rawCount = raw.map(rawPresent).count().unmask(0).rename('raw_obs');
function args(reducer) {
  return {reducer: reducer, geometry: roi, crs: proj, maxPixels: 10000000, bestEffort: false};
}

var sums = ee.Image.cat([validCount, rawCount, validCount.gt(0).rename('has_valid'),
                         ee.Image.constant(1).rename('roi_px')])
  .reduceRegion(args(ee.Reducer.sum().unweighted()));
var mean = meanAod.reduceRegion(args(ee.Reducer.mean().unweighted()));

var granules = raw.map(function (img) {
  var n = qaFilter(img).reduceRegion(args(ee.Reducer.count())).get('AOD_550');
  return img.set({tt_valid_px: n, tt_utc_day: ee.Date(img.get('system:time_start')).format('YYYY-MM-dd')});
});
var withValid = granules.filter(ee.Filter.gt('tt_valid_px', 0));

print('Native grid', proj, 'nominal scale (m)', proj.nominalScale());
print('Parity summary (compare with backend `summary`)', ee.Dictionary({
  granules_intersecting: raw.size(),
  granules_with_valid: withValid.size(),
  valid_day_count: withValid.aggregate_array('tt_utc_day').distinct().size(),
  valid_retrievals_granule_sum: granules.aggregate_sum('tt_valid_px'),
  valid_retrievals: sums.get('valid_obs'),
  retrievals_before_qa: sums.get('raw_obs'),
  pixels_with_valid: sums.get('has_valid'),
  pixels_total: sums.get('roi_px'),
  roi_mean_aod: mean.get('aod_mean')
}));

Map.centerObject(roi, 9);
Map.addLayer(roi, {color: 'white'}, 'ROI (as sent to backend)');
Map.addLayer(meanAod.clip(roi), {min: 0, max: 1, palette: ['cde2fb', '6da7ec', '2a78d6', '184f95', '0d366b']},
  'MAIAC AOD 550 nm mean | QA-filtered');
Map.addLayer(validCount.updateMask(validCount.gt(0)).clip(roi), {min: 1, max: 25,
  palette: ['f3bca8', 'e4744a', 'b13e02', '6f2401']}, 'Valid retrievals per pixel', false);
Map.addLayer(validCount.eq(0).selfMask().clip(roi), {palette: ['8a8a86']}, 'No valid retrieval');
print('Column AOD at 550 nm — not PM10, not mine-attributed dust.');
