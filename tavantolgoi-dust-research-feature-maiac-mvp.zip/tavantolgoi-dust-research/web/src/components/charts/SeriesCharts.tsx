import { useEffect, useRef, useState, type KeyboardEvent, type PointerEvent, type RefObject } from "react";
import type { MonthlyRow } from "../../api/types";
import { fmtAod, fmtInt, fmtPct, monthLabel, niceAxis } from "../../lib/format";

// Two small multiples sharing one x axis (never a dual-axis chart):
//   1. ROI mean AOD at 550 nm (line, 2px; 8px markers with a 2px surface ring)
//   2. Valid days per month (columns <= 24px, 4px rounded data end, square at the baseline)
// Months without valid retrievals are shaded bands — a gap, never a zero.

const M = { left: 44, right: 12, top: 10, bottom: 24 };
const H_AOD = 170;
const H_DAYS = 110;

interface Props {
  rows: MonthlyRow[];
  selectedMonth: string | null;
  onSelect: (month: string) => void;
}

function useWidth<T extends HTMLElement>(): [RefObject<T | null>, number] {
  const ref = useRef<T | null>(null);
  const [width, setWidth] = useState(640);
  useEffect(() => {
    if (!ref.current) return;
    const obs = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect.width;
      if (w) setWidth(Math.max(320, Math.floor(w)));
    });
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);
  return [ref, width];
}

function topRoundedBar(x: number, y: number, w: number, h: number, r: number): string {
  const rr = Math.min(r, w / 2, h);
  return `M${x},${y + h}V${y + rr}Q${x},${y} ${x + rr},${y}H${x + w - rr}Q${x + w},${y} ${x + w},${y + rr}V${y + h}Z`;
}

export function SeriesCharts({ rows, selectedMonth, onSelect }: Props) {
  const [boxRef, width] = useWidth<HTMLDivElement>();
  const [active, setActive] = useState<number | null>(null);
  const [pointer, setPointer] = useState<{ x: number; y: number } | null>(null);

  const n = rows.length;
  const plotW = width - M.left - M.right;
  const bw = plotW / Math.max(n, 1);
  const cx = (i: number) => M.left + (i + 0.5) * bw;
  const labelEvery = n <= 12 ? 1 : n <= 24 ? 2 : 3;

  const valid = rows.map((r) => (r.status === "OK" && r.roi_mean_aod !== null ? r.roi_mean_aod : null));
  const maxAod = Math.max(0, ...valid.filter((v): v is number => v !== null));
  const aodAxis = niceAxis(maxAod, 0.2);
  const aodInnerH = H_AOD - M.top - M.bottom;
  const yAod = (v: number) => M.top + aodInnerH * (1 - v / aodAxis.top);

  const daysTop = 31;
  const daysTicks = [0, 10, 20, 30];
  const daysInnerH = H_DAYS - M.top - M.bottom;
  const yDays = (v: number) => M.top + daysInnerH * (1 - v / daysTop);

  // Line path broken at missing months.
  let path = "";
  valid.forEach((v, i) => {
    if (v === null) return;
    const prevValid = i > 0 && valid[i - 1] !== null;
    path += `${prevValid ? "L" : "M"}${cx(i).toFixed(1)},${yAod(v).toFixed(1)}`;
  });
  const maxIndex = valid.findIndex((v) => v !== null && v === maxAod);

  const indexFromX = (clientX: number): number | null => {
    const rect = boxRef.current?.getBoundingClientRect();
    if (!rect || n === 0) return null;
    const i = Math.floor((clientX - rect.left - M.left) / bw);
    return i >= 0 && i < n ? i : null;
  };

  const onMove = (e: PointerEvent<HTMLDivElement>) => {
    const rect = boxRef.current?.getBoundingClientRect();
    setActive(indexFromX(e.clientX));
    if (rect) setPointer({ x: e.clientX - rect.left, y: e.clientY - rect.top });
  };

  const onKey = (e: KeyboardEvent<HTMLDivElement>) => {
    if (n === 0) return;
    if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
      e.preventDefault();
      const next = active === null ? 0 : Math.min(n - 1, Math.max(0, active + (e.key === "ArrowRight" ? 1 : -1)));
      setActive(next);
      setPointer({ x: cx(next), y: 40 });
    } else if (e.key === "Enter" && active !== null) {
      onSelect(rows[active]!.month);
    } else if (e.key === "Escape") {
      setActive(null);
    }
  };

  const xLabels = (h: number) =>
    rows.map((r, i) =>
      i % labelEvery === 0 ? (
        <text key={r.month} x={cx(i)} y={h - 6} textAnchor="middle" fontSize={11}
          fill={r.month === selectedMonth ? "var(--text-primary)" : "var(--text-muted)"}
          fontWeight={r.month === selectedMonth ? 600 : 400}>
          {monthLabel(r.month, false)}{r.month.endsWith("-01") || i === 0 ? ` ${r.month.slice(2, 4)}` : ""}
        </text>
      ) : null,
    );

  const gapBands = (h: number) =>
    rows.map((r, i) =>
      r.status !== "OK" ? (
        <g key={`gap-${r.month}`}>
          <rect x={M.left + i * bw + 1} y={M.top} width={Math.max(bw - 2, 1)} height={h - M.top - M.bottom}
            fill="var(--surface-3)" opacity={0.7} />
        </g>
      ) : null,
    );

  const markers = (h: number) => {
    const out = [];
    if (active !== null) {
      out.push(<line key="cross" x1={cx(active)} x2={cx(active)} y1={M.top} y2={h - M.bottom} stroke="var(--text-muted)" strokeWidth={1} />);
    }
    const sel = rows.findIndex((r) => r.month === selectedMonth);
    if (sel >= 0) {
      out.push(<line key="sel" x1={cx(sel)} x2={cx(sel)} y1={M.top} y2={h - M.bottom} stroke="var(--text-secondary)" strokeWidth={1} opacity={0.6} />);
    }
    return out;
  };

  const activeRow = active !== null ? rows[active] : undefined;
  const barW = Math.min(24, bw * 0.6);

  return (
    <div
      ref={boxRef}
      className="chart-box"
      tabIndex={0}
      role="group"
      aria-label="Monthly charts. Use left and right arrow keys to inspect months, Enter to show a month on the map."
      onPointerMove={onMove}
      onPointerLeave={() => { setActive(null); setPointer(null); }}
      onClick={(e) => { const i = indexFromX(e.clientX); if (i !== null) onSelect(rows[i]!.month); }}
      onKeyDown={onKey}
      style={{ cursor: "pointer" }}
    >
      <p className="chart-title">ROI mean AOD at 550 nm</p>
      <p className="chart-sub">Dimensionless · QA-filtered MAIAC · shaded months = no valid retrieval (missing, not zero)</p>
      <svg width={width} height={H_AOD} aria-hidden="true">
        {aodAxis.ticks.map((t) => (
          <g key={t}>
            <line x1={M.left} x2={width - M.right} y1={yAod(t)} y2={yAod(t)} stroke={t === 0 ? "var(--baseline)" : "var(--grid)"} strokeWidth={1} />
            <text x={M.left - 6} y={yAod(t) + 4} textAnchor="end" fontSize={11} fill="var(--text-muted)" className="tabular">{t.toFixed(2)}</text>
          </g>
        ))}
        {gapBands(H_AOD)}
        {markers(H_AOD)}
        <path d={path} fill="none" stroke="var(--series-1)" strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" />
        {valid.map((v, i) => (v === null ? null : (
          <circle key={rows[i]!.month} cx={cx(i)} cy={yAod(v)} r={active === i ? 5 : 4} fill="var(--series-1)" stroke="var(--surface-1)" strokeWidth={2} />
        )))}
        {maxIndex >= 0 && (
          <text x={cx(maxIndex)} y={yAod(maxAod) - 10} textAnchor="middle" fontSize={11} fill="var(--text-secondary)" className="tabular">
            {fmtAod(maxAod)}
          </text>
        )}
        {xLabels(H_AOD)}
      </svg>

      <p className="chart-title">Valid days per month</p>
      <p className="chart-sub">UTC days with ≥1 QA-passing retrieval anywhere in the ROI</p>
      <svg width={width} height={H_DAYS} aria-hidden="true">
        {daysTicks.map((t) => (
          <g key={t}>
            <line x1={M.left} x2={width - M.right} y1={yDays(t)} y2={yDays(t)} stroke={t === 0 ? "var(--baseline)" : "var(--grid)"} strokeWidth={1} />
            <text x={M.left - 6} y={yDays(t) + 4} textAnchor="end" fontSize={11} fill="var(--text-muted)" className="tabular">{t}</text>
          </g>
        ))}
        {gapBands(H_DAYS)}
        {markers(H_DAYS)}
        {rows.map((r, i) => {
          if (r.valid_day_count <= 0) return null;
          const y = yDays(r.valid_day_count);
          const h = yDays(0) - y;
          return (
            <path key={r.month} d={topRoundedBar(cx(i) - barW / 2, y, barW, h, 4)} fill="var(--series-3)"
              opacity={active === null || active === i ? 1 : 0.75} />
          );
        })}
        {xLabels(H_DAYS)}
      </svg>

      {activeRow && pointer && (
        <div className="tooltip" style={{ left: Math.min(pointer.x + 14, width - 210), top: Math.max(0, pointer.y - 20) }}>
          <div className="t-head">{monthLabel(activeRow.month)}</div>
          {activeRow.status === "OK" ? (
            <div className="t-row"><span className="key" style={{ background: "var(--series-1)" }} /><strong>{fmtAod(activeRow.roi_mean_aod)}</strong><span className="muted">mean AOD 550 nm</span></div>
          ) : (
            <div className="t-row"><strong>{activeRow.status === "NO_GRANULES" ? "No granules" : "No valid retrieval"}</strong></div>
          )}
          <div className="t-row"><span className="key" style={{ background: "var(--series-3)" }} /><strong>{activeRow.valid_day_count} / {activeRow.days_in_period}</strong><span className="muted">valid days</span></div>
          <div className="t-row"><strong>{fmtPct(activeRow.coverage_fraction)}</strong><span className="muted">ROI pixel coverage</span></div>
          <div className="t-row"><strong>{fmtInt(activeRow.valid_retrievals)}</strong><span className="muted">valid retrievals ({fmtPct(activeRow.qa_retention_fraction)} QA retention)</span></div>
          <div className="t-row muted small">Click to show this month on the map</div>
        </div>
      )}
    </div>
  );
}
