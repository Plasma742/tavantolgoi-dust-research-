import { useEffect, useState } from "react";
import { api, ApiError } from "../api/client";
import type { DatasetsResponse, MethodsResponse } from "../api/types";

export function MethodsPage() {
  const [datasets, setDatasets] = useState<DatasetsResponse | null>(null);
  const [methods, setMethods] = useState<MethodsResponse | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    Promise.all([api.datasets(), api.methods()])
      .then(([d, m]) => {
        setDatasets(d);
        setMethods(m);
      })
      .catch((err: unknown) => setError(err instanceof ApiError ? err.message : "Could not load method documentation."));
  }, []);

  return (
    <div className="page">
      <h2>Data &amp; methods</h2>
      <p>
        This platform separates <strong>satellite observations</strong>, <strong>meteorological model / reanalysis fields</strong>,
        <strong> statistical attribution</strong> and <strong>dispersion simulation</strong>. Only the first is implemented:
        QA-filtered MAIAC aerosol optical depth at 550 nm. Nothing here measures PM10 or attributes dust to the mine.
      </p>
      {error && <div className="callout critical" role="alert"><span className="icon">✕</span>{error}</div>}

      {methods && (
        <>
          <h3>MAIAC AOD processing <span className="badge">{methods.method_version}</span></h3>
          <dl className="kv">
            <dt>Dataset</dt><dd><code>{methods.maiac.dataset_id}</code> · band <code>{methods.maiac.band}</code> · QA <code>{methods.maiac.qa_band}</code></dd>
            <dt>Scaling</dt><dd>× {methods.maiac.scale_factor} → {methods.maiac.unit} AOD</dd>
            <dt>Quality filter</dt><dd>{methods.maiac.quality_filter}</dd>
            <dt>Temporal aggregation</dt><dd>{methods.maiac.temporal_aggregation}</dd>
            <dt>Spatial reduction</dt><dd>{methods.maiac.spatial_reduction}</dd>
            <dt>Not a measurement of</dt><dd>{methods.maiac.not_a_measurement_of.join(" · ")}</dd>
            <dt>Caveat</dt><dd>{methods.maiac.caveat}</dd>
            <dt>Citation</dt><dd>{methods.maiac.citation}</dd>
            <dt>Code revision</dt><dd>{methods.code_revision ?? "unknown"}</dd>
          </dl>
          <h3>Open methodology questions (for scientific review)</h3>
          <ul>{methods.maiac.open_methodology_questions.map((q) => <li key={q}>{q}</li>)}</ul>
          <h3>Compute quota</h3>
          <p>{methods.quota_note}</p>
        </>
      )}

      {datasets && (
        <>
          <h2>Dataset catalog</h2>
          <div className="cards">
            {datasets.datasets.map((d) => (
              <article className="card" key={d.key}>
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <h3>{d.title}</h3>
                  <span className="badge">{d.status === "implemented" ? "✓ Implemented" : "Planned"}</span>
                </div>
                <div className="small secondary">{d.observation_type_label}</div>
                <div className="small"><code>{d.collection_id}</code></div>
                <div className="small muted">Grid: {d.native_grid} · {d.temporal_support}</div>
                <div className="small muted">Variables: {d.variables.map((v) => `${v.band} (${v.unit})`).join("; ")}</div>
                <ul className="small">{d.caveats.map((c) => <li key={c}>{c}</li>)}</ul>
                <div className="small muted">{d.metadata_note}</div>
                <a className="small" href={d.catalog_url} target="_blank" rel="noreferrer noopener">Earth Engine catalog</a>
              </article>
            ))}
          </div>

          <h2>Not yet available</h2>
          <div className="cards">
            {datasets.unavailable_modules.map((m) => (
              <article className="card" key={m.key}>
                <div className="row" style={{ justifyContent: "space-between" }}>
                  <h3>{m.title}</h3>
                  <span className="badge">Not yet available</span>
                </div>
                <p className="small">{m.reason}</p>
              </article>
            ))}
          </div>
        </>
      )}

      <h2>Display context</h2>
      <p>
        The satellite basemap is display context only and is not used in any computation. Earth Engine tiles are proxied by
        the backend, so no Google credentials or Earth Engine URLs reach the browser.
      </p>
    </div>
  );
}
