import { useState } from "react";
import type { MonthlySeriesResponse } from "../api/types";
import { fmtAod, fmtInt, fmtPct, monthLabel } from "../lib/format";
import { monthsBetween } from "../lib/period";
import { SeriesCharts } from "./charts/SeriesCharts";

interface Props {
  series: MonthlySeriesResponse | null;
  loading: boolean;
  error: string | null;
  startMonth: string;
  endMonth: string;
  maxMonths: number;
  canCompute: boolean;
  disabledReason: string | null;
  selectedMonth: string | null;
  onRange: (start: string, end: string) => void;
  onCompute: () => void;
  onCsv: () => void;
  onSelectMonth: (month: string) => void;
}

export function TimeSeriesPanel(props: Props) {
  const { series, loading, error, startMonth, endMonth, maxMonths, canCompute, disabledReason, selectedMonth } = props;
  const [showTable, setShowTable] = useState(false);
  const count = monthsBetween(startMonth, endMonth);
  const rangeProblem = count < 1 ? "End month is before start month." : count > maxMonths ? `Limit is ${maxMonths} months.` : null;
  const failedChecks = series?.rows.filter((r) => !r.consistency_check_passed).length ?? 0;

  return (
    <section className="series" aria-labelledby="series-h">
      <div className="series-head">
        <h2 id="series-h">Monthly ROI time series · MAIAC AOD 550 nm</h2>
        <label className="field">
          From
          <input type="month" value={startMonth} min="2000-03" onChange={(e) => e.target.value && props.onRange(e.target.value, endMonth)} />
        </label>
        <label className="field">
          To (inclusive)
          <input type="month" value={endMonth} min={startMonth} onChange={(e) => e.target.value && props.onRange(startMonth, e.target.value)} />
        </label>
        <button className="btn primary" type="button" onClick={props.onCompute} disabled={!canCompute || loading || rangeProblem !== null}>
          {loading ? "Computing…" : `Compute ${count > 0 ? count : ""} months`}
        </button>
        <button className="btn" type="button" onClick={props.onCsv} disabled={!series || loading}>Export CSV</button>
        <button className="btn" type="button" aria-pressed={showTable} onClick={() => setShowTable((v) => !v)} disabled={!series}>
          {showTable ? "Show chart" : "Show table"}
        </button>
      </div>
      {rangeProblem && <p className="small muted">{rangeProblem}</p>}
      {disabledReason && !series && <p className="small muted">{disabledReason}</p>}
      {error && <div className="callout critical" role="alert"><span className="icon">✕</span>{error}</div>}
      {failedChecks > 0 && (
        <div className="callout critical" role="alert">
          <span className="icon">✕</span>{failedChecks} month(s) failed the internal count-consistency check. Treat them as unreliable.
        </div>
      )}
      {!series && !error && (
        <p className="small muted">
          No series computed. Each month is an Earth Engine computation counted against the project's monthly EECU quota,
          so the series is computed only when you ask for it.
        </p>
      )}
      {series && (
        <div className={loading ? "refetching" : undefined}>
          {showTable ? (
            <div className="table-scroll">
              <table className="data tabular">
                <thead>
                  <tr>
                    <th>Month</th><th>Status</th><th>Mean AOD 550</th><th>Valid days</th><th>Coverage</th>
                    <th>Valid retrievals</th><th>QA retention</th><th>Granules (valid / all)</th><th>Check</th>
                  </tr>
                </thead>
                <tbody>
                  {series.rows.map((r) => (
                    <tr key={r.month}>
                      <td>{monthLabel(r.month)}</td>
                      <td>{r.status}</td>
                      <td>{r.status === "OK" ? fmtAod(r.roi_mean_aod) : "—"}</td>
                      <td>{r.valid_day_count} / {r.days_in_period}</td>
                      <td>{fmtPct(r.coverage_fraction)}</td>
                      <td>{fmtInt(r.valid_retrievals)}</td>
                      <td>{fmtPct(r.qa_retention_fraction)}</td>
                      <td>{r.granules_with_valid} / {r.granules_intersecting}</td>
                      <td>{r.consistency_check_passed ? "✓ pass" : "✕ fail"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <SeriesCharts rows={series.rows} selectedMonth={selectedMonth} onSelect={props.onSelectMonth} />
          )}
          <p className="small muted" style={{ marginBottom: 0 }}>
            Monthly ROI means summarise whatever retrievals survived QA; months with low coverage or few valid days are less
            representative. No trend, uncertainty interval or attribution is implied.
          </p>
        </div>
      )}
    </section>
  );
}
