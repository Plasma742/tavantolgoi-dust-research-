import type { PeriodSummary } from "../api/types";
import { fmtAod, fmtInt, fmtPct } from "../lib/format";
import { describeWindow } from "../lib/period";

export function StatusCallout({ summary }: { summary: PeriodSummary }) {
  if (summary.status === "OK") return null;
  return (
    <div className="callout warning" role="status">
      <span className="icon">!</span>
      <strong>{summary.status === "NO_GRANULES" ? "No granules" : "No valid observations"}</strong> — {summary.status_message}
    </div>
  );
}

export function SummaryPanel({ summary, onOpenProvenance }: { summary: PeriodSummary | null; onOpenProvenance: () => void }) {
  return (
    <section className="section" aria-labelledby="summary-h">
      <h2 id="summary-h">4 · Period summary</h2>
      {!summary ? (
        <p className="small muted">Load a layer to see ROI statistics. No values are shown before Earth Engine returns them.</p>
      ) : (
        <div className="stack">
          <p className="small muted" style={{ margin: 0 }}>
            {describeWindow(summary.time_start_utc.slice(0, 10), summary.time_end_exclusive_utc.slice(0, 10))}
          </p>
          <StatusCallout summary={summary} />
          <div className="tiles">
            <div className="tile wide">
              <div className="label">ROI mean AOD at 550 nm</div>
              <div className="value">{fmtAod(summary.roi_mean_aod)}</div>
              <div className="sub">dimensionless · mean of per-pixel period means · shown to 0.001 (product quantisation, not uncertainty)</div>
            </div>
            <div className="tile">
              <div className="label">Spatial coverage</div>
              <div className="value">{fmtPct(summary.coverage_fraction)}</div>
              <div className="sub">{fmtInt(summary.pixels_with_valid)} of {fmtInt(summary.pixels_total)} ROI pixels with ≥1 valid retrieval</div>
            </div>
            <div className="tile">
              <div className="label">Valid days</div>
              <div className="value">{summary.valid_day_count} / {summary.days_in_period}</div>
              <div className="sub">UTC days with ≥1 valid retrieval in ROI</div>
            </div>
            <div className="tile">
              <div className="label">Valid retrievals</div>
              <div className="value">{fmtInt(summary.valid_retrievals)}</div>
              <div className="sub">QA retention {fmtPct(summary.qa_retention_fraction)} of {fmtInt(summary.retrievals_before_qa)} AOD values</div>
            </div>
            <div className="tile">
              <div className="label">Granules</div>
              <div className="value">{summary.granules_with_valid} / {summary.granules_intersecting}</div>
              <div className="sub">with valid retrievals / intersecting ROI</div>
            </div>
          </div>
          <div className={`callout ${summary.consistency_check_passed ? "good" : "critical"}`}>
            <span className="icon">{summary.consistency_check_passed ? "✓" : "✕"}</span>
            {summary.consistency_check_passed
              ? "Internal check passed: pixel-sum and per-granule counts agree."
              : "Internal check FAILED: pixel-sum and per-granule valid counts disagree. Do not use these numbers."}
          </div>
          <button className="btn small" type="button" onClick={onOpenProvenance}>Provenance &amp; method…</button>
        </div>
      )}
    </section>
  );
}
